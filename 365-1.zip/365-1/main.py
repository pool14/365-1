from flask import  Flask, render_template

app = Flask(__name__)

@app.route('/hola')
def hola():
    return 'hola'

# ruta paises
@app.route("/paises")
def paises():
    username = "Pepe"
    continentes = [
        {
        "nombre" : "America",
        "poblacion" : 1036900579,
        "superficie" : "42549000 Km2",
        "numeropaises" :"35",
        "densidad" :"22,8 habitantes/Km2",
        "paises" :[
          {
           "nom": "colombia",
           "mon": "Cop",
           "cap": "Bogota",
           "pob": "51,52 millones"
           },
          {"nom": "argentina",
           "mon": "Peso argentino",
           "cap": "Buenos aires",
           "pob": "45 millones"
           },
          
          {"nom": "chile",
           "mon": "peso chileno",
           "cap": "Santiago de chile",
           "pob": "19,49 millones"
           }
           
        ]
        },
        {
        "nombre" : "Europa",
        "poblacion" : 747747395,
        "superficie" : "10530751",
        "numeropaises" :"50",
        "densidad" :"71 habitantes/Km2",
        "paises" :[
            {
           "nom": "españa",
           "mon": "Euro",
           "cap": "Madrid",
           "pob": "39,49 millones"
           },
            
            {
           "nom": "francia",
           "mon": "Euro",
           "cap": "Paris",
           "pob": "59,49 millones"
           }
            
        ]
        },
        {
        "nombre" : "Africa",
        "poblacion" : 1320000000,
        "superficie" : "30221535",
        "numeropaises" :"54",
        "densidad" :"43,7 habitantes/Km2",
        "paises" :[
             {
           "nom": "nigeria",
           "mon": "Naira",
           "cap": "abuya",
           "pob": "19,49 millones"
           },
             
             {
           "nom": "ghana",
           "mon": "Cedi",
           "cap": "Acra",
           "pob": "19,49 millones"
           }
            
        ]
        }      
    ]
    return render_template('paises.html', username=username
                           ,continentes=continentes) 